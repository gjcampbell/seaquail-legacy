# Introduction

Sea Quail is a SQL Writing Library. Its purpose is to provide to .Net projects a set of tools for generating SQL. It is presented as a an extensible, flexible framework for generating SQL for many database management systems, abstracting the rendering of SQL statements through object oriented conventions.

Continue to a [Schema Manipulation](Schema-Manipulation) guide, a [Data Manipulation](Data-Manipulation) guide. 
Or see [Notes on Supported Features and Such](Notes-on-Supported-Features-and-Such), [Class Definitions](Class-Definitions)