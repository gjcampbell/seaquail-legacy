# Sea Quail SQL Writing Library Documentation

## Index

* [Introduction](Introduction)
* Implementation Guide
	* Schema Manipulation
		* Tables and Columns
		* Foreign Keys
	* Data Manipulation
		* Queries
			* [Conditions](Conditions)
			* [Joins](Joins)
			* Parameters
		* Insert
		* Update
		* Select
		* Delete
* Class Definitions
* Notes on Supported Features and Such
