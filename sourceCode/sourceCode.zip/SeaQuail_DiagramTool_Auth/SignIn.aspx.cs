﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SeaQuail_DiagramTool.Model;

namespace SeaQuail_DiagramTool
{
    public partial class SignIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string email = Request["openid.ext1.value.email"],
            //    id = Request["openid.identity"];

            //DGUser user = DGUser.ByExternalID(id)
            //    ?? new DGUser() { ExternalID = id, Name = email };

            //user.Save();

            //Session.SetUser(user);
        }
    }
}
