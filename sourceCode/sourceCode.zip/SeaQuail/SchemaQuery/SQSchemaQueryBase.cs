﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeaQuail.SchemaQuery
{
    public abstract class SQSchemaQueryBase
    {
    }
}
