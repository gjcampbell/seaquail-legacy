﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeaQuail.SchemaQuery
{
    public class SQRemoveIndex : SQSchemaQueryBase
    {
        public string IndexName { get; set; }
    }
}
