﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SeaQuail.Data
{
    public class SQVariable
    {
        public string Name { get; set; }
    }
}
